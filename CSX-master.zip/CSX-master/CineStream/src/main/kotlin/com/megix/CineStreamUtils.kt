package com.megix

// Cloudstream & NiceHttp
import com.lagradost.api.Log
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.APIHolder.unixTimeMS
import com.lagradost.cloudstream3.utils.*
import com.lagradost.cloudstream3.utils.AppUtils.parseJson
import com.lagradost.cloudstream3.utils.AppUtils.toJson
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson

// Coroutines
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

// Network
import java.net.*
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.RequestBody.Companion.toRequestBody

// JSON & HTML Parsing
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

// Java Utils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// Security & Crypto
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.math.BigInteger
import kotlin.math.min

// Settings
import com.megix.settings.Settings


class SpecOption(searchTerms: List<String>, val label: String) {
    constructor(term: String, label: String) : this(listOf(term), label)

    val regex = Regex(
        searchTerms.joinToString(
            separator = "|",
            prefix = "(?i)(?<=^|\\W)(?:",
            postfix = ")(?=[^a-zA-Z0-9_+]|$)"
        ) {
            Regex.escape(it)
        }
    )
}

val SPEC_OPTIONS = mapOf(
    "quality" to listOf(
        SpecOption("UHD BluRay", "4K UHD BluRay 💿"),
        SpecOption("BluRay", "BluRay 💿"),
        SpecOption("BluRay REMUX", "BluRay REMUX 💾"),
        SpecOption("BDRip", "BDRip 💿"),
        SpecOption("BRRip", "BRRip 💿"),
        SpecOption("DVD", "DVD Full/ISO 📀"),
        SpecOption("DVDRip", "DVDRip 📀"),
        SpecOption("DVD5", "DVD5 📀"),
        SpecOption("DVD9", "DVD9 📀"),
        SpecOption("HD-DVD", "HD-DVD 📀"),
        SpecOption("WEB-DL", "WEB-DL ☁️"),
        SpecOption("WEBRip", "WEBRip 🌐"),
        SpecOption("HDRip", "HDRip ✨"),
        SpecOption("HDTV", "HDTV 📺"),
        SpecOption("PDTV", "PDTV 📺"),
        SpecOption("SDTV", "SDTV 📺"),
        SpecOption("PPV", "PPV 🎫"),
        SpecOption("SATRip", "SATRip 📡"),
        SpecOption("DSR", "DSRip 📡"),
        SpecOption("TVRip", "TVRip 📺"),
        SpecOption("CAM", "CAM 📹"),
        SpecOption("TeleSync", "TeleSync 📹"),
        SpecOption("TS", "TS 🚫"),
        SpecOption("TC", "TeleCine 🎞️"),
        SpecOption("SCR", "SCR 📼"),
        SpecOption("DVDScr", "DVDScr 📼"),
        SpecOption("R5", "R5 ⁵"),
        SpecOption("VHS", "VHS 📼"),
        SpecOption("LaserDisc", "LaserDisc 💿")
    ),
    "codec" to listOf(
        SpecOption("av1", "AV1 🚀"),
        SpecOption(listOf("x265", "h.265", "hevc"), "HEVC ⚡"),
        SpecOption("vp9", "VP9 🧪"),
        SpecOption("vp8", "VP8 🧪"),
        SpecOption(listOf("x264", "h.264", "H264", "avc"), "H.264 📦"),
        SpecOption("vc-1", "VC-1 📼"),
        SpecOption("mpeg-2", "MPEG-2 🎞️"),
        SpecOption("mpeg-4", "MPEG-4 🎞️"),
        SpecOption("xvid", "XviD 🧩"),
        SpecOption("divx", "DivX 🧩"),
        SpecOption("wmv", "WMV 🪟"),
        SpecOption("theora", "Theora 🦦"),
        SpecOption("realvideo", "RealVideo 🎥"),
        SpecOption("h.263", "H.263 📱")
    ),
    "bitdepth" to listOf(
        SpecOption("12bit", "12bit 🌈"),
        SpecOption("10bit", "10bit 🎨"),
        SpecOption("Hi10P", "Hi10P (10bit) 🎨"),
        SpecOption("8bit", "8bit 🖍️"),
        SpecOption("3D", "3D 👓"),
        SpecOption("SBS", "3D SBS ↔️"),
        SpecOption("OU", "3D Over/Under ↕️"),
        SpecOption("IMAX", "IMAX 🏟️")
    ),
    "audio" to listOf(
        SpecOption("TrueHD", "Dolby TrueHD 🔊"),
        SpecOption("Atmos", "Dolby Atmos 🌌"),
        SpecOption(listOf("DDP5.1", "DDP 5.1"), "DD+ 5.1 🔉"),
        SpecOption("7.1", "7.1 Ch 🔊"),
        SpecOption("5.1", "5.1 Ch 🔉"),
        SpecOption("DTS-HD MA", "DTS-HD MA 🔊"),
        SpecOption("DTS-HD", "DTS-HD 🔊"),
        SpecOption("DTS:X", "DTS:X 🔊"),
        SpecOption("DTS Lossless", "DTS Lossless 🎼"),
        SpecOption("DTS-ES", "DTS-ES 🔉"),
        SpecOption("PCM", "LPCM/PCM 💿"),
        SpecOption("FLAC", "FLAC 🎹"),
        SpecOption("ALAC", "ALAC 🍏"),
        SpecOption("WAV", "WAV 🌊"),
        SpecOption("AIFF", "AIFF 🎼"),
        SpecOption(listOf("AAC2.0", "AAC 2.0"), "AAC 2.0 🎧"),
        SpecOption("DD2.0", "DD 2.0 🎧"),
        SpecOption(listOf("E-AC3", "DD+", "Dolby Digital Plus"), "DD+ 🔉"),
        SpecOption("AC3", "AC3 (Dolby Digital) 🔈"),
        SpecOption("DD5.1", "Dolby Digital 5.1 🔈"),
        SpecOption("DTS", "DTS 🔈"),
        SpecOption("AAC", "AAC 🎧"),
        SpecOption("HE-AAC", "HE-AAC 🎧"),
        SpecOption("OPUS", "Opus 🎙️"),
        SpecOption("VORBIS", "Vorbis 🌀"),
        SpecOption("MP3", "MP3 🎵"),
        SpecOption("WMA", "WMA 🎵"),
        SpecOption("OGG", "OGG 🌀"),
        SpecOption("MP2", "MP2 📻")
    ),
    "hdr" to listOf(
        SpecOption(listOf("DV", "DoVi", "DOLBYVISION", "Dolby Vision"), "Dolby Vision 👁️"),
        SpecOption("HDR10+", "HDR10+ 🔆"),
        SpecOption("HDR10", "HDR10 🔆"),
        SpecOption("HLG", "HLG 📡"),
        SpecOption("HDR", "HDR 🔆"),
        SpecOption("SDR", "SDR 🔅")
    ),
    "language" to listOf(
        SpecOption(listOf("HIN", "Hindi"), "Hindi 🇮🇳"),
        SpecOption("Tamil", "Tamil 🇮🇳"),
        SpecOption("Telugu", "Telugu 🇮🇳"),
        SpecOption("Malayalam", "Malayalam 🇮🇳"),
        SpecOption("Kannada", "Kannada 🇮🇳"),
        SpecOption("Bengali", "Bengali 🇮🇳"),
        SpecOption("Punjabi", "Punjabi 🇮🇳"),
        SpecOption(listOf("ENG", "English"), "English 🇺🇸"),
        SpecOption(listOf("KOR", "Korean"), "Korean 🇰🇷"),
        SpecOption(listOf("JPN", "Japanese"), "Japanese 🇯🇵"),
        SpecOption(listOf("CHN", "Chinese"), "Chinese 🇨🇳"),
        SpecOption("Spanish", "Spanish 🇪🇸"),
        SpecOption("French", "French 🇫🇷"),
        SpecOption("German", "German 🇩🇪"),
        SpecOption("Italian", "Italian 🇮🇹"),
        SpecOption("Russian", "Russian 🇷🇺"),
        SpecOption("Arabic", "Arabic 🇸🇦"),
        SpecOption(listOf("Multi-Audio", "Multi Audio", "Multi.Audio"), "Multi Audio 🌍"),
        SpecOption(listOf("Dual.Audio", "Dual Audio", "Dual"), "Dual Audio 🌗"),
        SpecOption(listOf("Multi-Sub", "MultiSub", "Multi Sub"), "Multi Subs 💬"),
        SpecOption("ESub", "English Subs 🇺🇸")
    )
)

private val SIZE_REGEX = """(\d+(?:\.\d+)?\s?(?:MB|GB))""".toRegex(RegexOption.IGNORE_CASE)
private val CATEGORY_ORDER = listOf("quality", "codec", "bitdepth", "audio", "hdr", "language")

fun getSimplifiedTitle(title: String): String {
    var remainingTitle = title
    val matchedLabels = mutableListOf<String>()

    CATEGORY_ORDER.forEach { category ->
        SPEC_OPTIONS[category].orEmpty().forEach { spec ->
            if (spec.regex.containsMatchIn(remainingTitle)) {
                matchedLabels.add(spec.label)
                remainingTitle = spec.regex.replace(remainingTitle, " ")
            }
        }
    }

    val sizeMatch = SIZE_REGEX.find(title)?.value?.uppercase()
    val size = sizeMatch?.let { "$it 💾" }

    val result = listOfNotNull(
        matchedLabels.distinct().joinToString(" | ").takeIf { it.isNotEmpty() },
        size
    ).joinToString(" | ")

    return if (result.isEmpty()) "" else "\n$result"
}

val languageMap = mapOf(
    "Afrikaans" to listOf("af", "afr"),
    "Albanian" to listOf("sq", "sqi"),
    "Amharic" to listOf("am", "amh"),
    "Arabic" to listOf("ar", "ara"),
    "Armenian" to listOf("hy", "hye"),
    "Azerbaijani" to listOf("az", "aze"),
    "Basque" to listOf("eu", "eus"),
    "Belarusian" to listOf("be", "bel"),
    "Bengali" to listOf("bn", "ben"),
    "Bosnian" to listOf("bs", "bos"),
    "Bulgarian" to listOf("bg", "bul"),
    "Catalan" to listOf("ca", "cat"),
    "Chinese" to listOf("zh", "zho"),
    "Croatian" to listOf("hr", "hrv"),
    "Czech" to listOf("cs", "ces"),
    "Danish" to listOf("da", "dan"),
    "Dutch" to listOf("nl", "nld"),
    "English" to listOf("en", "eng"),
    "Estonian" to listOf("et", "est"),
    "Filipino" to listOf("tl", "tgl", "fil"),
    "Finnish" to listOf("fi", "fin"),
    "French" to listOf("fr", "fra"),
    "Galician" to listOf("gl", "glg"),
    "Georgian" to listOf("ka", "kat"),
    "German" to listOf("de", "deu", "ger"),
    "Greek" to listOf("el", "ell"),
    "Gujarati" to listOf("gu", "guj"),
    "Hebrew" to listOf("he", "heb"),
    "Hindi" to listOf("hi", "hin"),
    "Hungarian" to listOf("hu", "hun"),
    "Icelandic" to listOf("is", "isl"),
    "Indonesian" to listOf("id", "ind"),
    "Italian" to listOf("it", "ita"),
    "Japanese" to listOf("ja", "jpn"),
    "Kannada" to listOf("kn", "kan"),
    "Kazakh" to listOf("kk", "kaz"),
    "Korean" to listOf("ko", "kor"),
    "Latvian" to listOf("lv", "lav"),
    "Lithuanian" to listOf("lt", "lit"),
    "Macedonian" to listOf("mk", "mkd"),
    "Malay" to listOf("ms", "msa"),
    "Malayalam" to listOf("ml", "mal"),
    "Maltese" to listOf("mt", "mlt"),
    "Marathi" to listOf("mr", "mar"),
    "Mongolian" to listOf("mn", "mon"),
    "Nepali" to listOf("ne", "nep"),
    "Norwegian" to listOf("no", "nor"),
    "Persian" to listOf("fa", "fas"),
    "Polish" to listOf("pl", "pol"),
    "Portuguese" to listOf("pt", "por"),
    "Punjabi" to listOf("pa", "pan"),
    "Romanian" to listOf("ro", "ron"),
    "Russian" to listOf("ru", "rus"),
    "Serbian" to listOf("sr", "srp"),
    "Sinhala" to listOf("si", "sin"),
    "Slovak" to listOf("sk", "slk"),
    "Slovenian" to listOf("sl", "slv"),
    "Spanish" to listOf("es", "spa"),
    "Swahili" to listOf("sw", "swa"),
    "Swedish" to listOf("sv", "swe"),
    "Tamil" to listOf("ta", "tam"),
    "Telugu" to listOf("te", "tel"),
    "Thai" to listOf("th", "tha"),
    "Turkish" to listOf("tr", "tur"),
    "Ukrainian" to listOf("uk", "ukr"),
    "Urdu" to listOf("ur", "urd"),
    "Uzbek" to listOf("uz", "uzb"),
    "Vietnamese" to listOf("vi", "vie"),
    "Welsh" to listOf("cy", "cym"),
    "Yiddish" to listOf("yi", "yid")
)

fun getLanguage(language: String?): String? {

    language ?: return null

    var normalizedLang = if(language.contains("-")) {
        language.substringBefore("-")
    } else if(language.contains(" ")) {
        language.substringBefore(" ")
    } else if(language.contains("CR_")) {
        language.substringAfter("CR_")
    } else {
        language
    }

    if(normalizedLang.isBlank()) {
        normalizedLang =  language
    }

    val tag = languageMap.entries.find { entry ->
        entry.value.contains(normalizedLang)
    }?.key

    if(tag == null) {
        return normalizedLang
    }
    return tag
}

fun String.getHost(): String {
    return fixTitle(URI(this).host.substringBeforeLast(".").substringAfterLast("."))
}

fun String.queryParams(): Map<String, String> {
    return split("&").mapNotNull {
        val parts = it.split("=", limit = 2)
        if (parts.size == 2) parts[0] to java.net.URLDecoder.decode(parts[1], "UTF-8")
        else null
    }.toMap()
}

fun JSONObject?.toStringMap(): Map<String, String> {
    val map = mutableMapOf<String, String>()
    this?.keys()?.forEach { k -> map[k] = this.optString(k) }
    return map
}

suspend fun checkPosterAvailable(posterUrl: String? = null): String? {
    if(posterUrl == null) return null
    return try {
        val res = app.head(posterUrl)
        if (res.code == 200) {
            posterUrl
        } else {
            null
        }

    } catch (e: Exception) {
        null
    }
}

suspend fun getTvdbData(tvType: String, imdbId: String? = null): ExtractedMediaData? {
    if (imdbId == null) return null
    val primaryUrl = "https://aiometadata.elfhosted.com/stremio/9197a4a9-2f5b-4911-845e-8704c520bdf7/meta/$tvType/$imdbId.json"
    var jsonText = try {
        app.get(primaryUrl, timeout = 6L).text
    } catch (e: Exception) {
        ""
    }

    if (jsonText.isEmpty()) {
        val fallbackUrl = "https://94c8cb9f702d-tmdb-addon.baby-beamup.club/meta/$tvType/$imdbId.json"
        jsonText = try {
            app.get(fallbackUrl, timeout = 6L).text
        } catch (e: Exception) {
            ""
        }
    }

    if (jsonText.isEmpty()) return null

    val root = JSONObject(jsonText)
    val meta = root.optJSONObject("meta") ?: return null
    val image_proxy = "https://wsrv.nl/?url="
    val posterUrl = meta.optString("poster").takeIf { it.isNotEmpty() }?.let { "$image_proxy$it" }
    val backgroundUrl = meta.optString("background").takeIf { it.isNotEmpty() }?.let { "$image_proxy$it" }
    val logoUrl = meta.optString("logo").takeIf { it.isNotEmpty() }?.let { "$image_proxy$it" }

    val castArray = meta.optJSONObject("app_extras")?.optJSONArray("cast")
    val castList = if (castArray != null) {
        (0 until castArray.length()).mapNotNull { i ->
            val castMember = castArray.optJSONObject(i) ?: return@mapNotNull null

            val name = castMember.optString("name")
            if (name.isNotEmpty() && name != "null") {
                ActorData(
                    Actor(
                        name = name,
                        image = castMember.optString("photo")
                            .takeIf { it.isNotEmpty() && it != "null" }
                            ?.let { "$image_proxy$it" }
                    ),
                    roleString = castMember.optString("character")
                        .takeIf { it.isNotEmpty() && it != "null" }
                )
            } else null
        }
    } else null

    return ExtractedMediaData(castList, posterUrl, backgroundUrl, logoUrl)
}

fun buildMagnetString(stream: TorrentioStream): String {
    val trackersString = stream.sources
        ?.asSequence()
        ?.filter { it.startsWith("tracker:", ignoreCase = true) }
        ?.map { it.substringAfter("tracker:").trim() }
        ?.filter { it.isNotEmpty() }
        ?.distinct()
        ?.joinToString("") { "&tr=$it" }
        ?: ""
    return "magnet:?xt=urn:btih:${stream.infoHash}&dn=${stream.infoHash}$trackersString&index=${stream.fileIdx}"
}

fun getFirstCharacterOrZero(input: String): String {
    val firstChar = input[0]
    return if (!firstChar.isLetter()) {
        "0"
    } else {
        firstChar.toString()
    }
}

fun getBaseUrl(url: String): String {
    try {
        return URI(url).let {
            "${it.scheme}://${it.host}"
        }
    } catch (e: Exception) {
        return url
    }
}

fun String?.createSlug(): String? {
    return this?.filter { it.isWhitespace() || it.isLetterOrDigit() }
        ?.trim()
        ?.replace("\\s+".toRegex(), "-")
        ?.lowercase()
}

fun quote(s: String): String =
    URLEncoder.encode(s, "UTF-8").replace("+", "%20")

fun String.capitalizeServer() = replaceFirstChar { it.uppercase() }

suspend fun extractMdrive(url: String): List<String> {
    val doc = app.get(url).document
    return doc.select("a")
        .mapNotNull { it.attr("href").takeIf { href ->
            href.contains(Regex("hubcloud|gdflix|gdlink", RegexOption.IGNORE_CASE))
        }}
}

fun getDate(): TmdbDate {
    val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val calendar = Calendar.getInstance()

    // Today
    val today = formatter.format(calendar.time)

    // Next week
    calendar.add(Calendar.WEEK_OF_YEAR, 1)
    val nextWeek = formatter.format(calendar.time)

    // Last week's Monday
    calendar.time = Date()
    calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    calendar.add(Calendar.WEEK_OF_YEAR, -1)
    val lastWeekStart = formatter.format(calendar.time)

    // Start of current month
    calendar.time = Date()
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val monthStart = formatter.format(calendar.time)

    return TmdbDate(today, nextWeek, lastWeekStart, monthStart)
}

fun isUpcoming(dateString: String?): Boolean {
    return try {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateTime = dateString?.let { format.parse(it)?.time } ?: return false
        unixTimeMS < dateTime
    } catch (t: Throwable) {
        //logError(t)
        false
    }
}

fun getUrlTitle(str: String?): String {
    if(str.isNullOrBlank()) return ""
    return str.replace(Regex("[^a-zA-Z\\d]"), "-")
}

suspend fun returnWorkingUrl(urls: List<String>): String? {
    for (url in urls) {
        try {
            val res = app.head(url, timeout = 30000L, allowRedirects = false)
            if (res.code == 200) {
                return url
            }
        } catch (e: Exception) {
            //logError(e)
            continue
        }
    }
    return null
}

suspend fun <T> retry(
    times: Int = 3,
    delayMs: Long = 1000,
    block: suspend () -> T?
): T? {

    repeat(times - 1) {
        runCatching {
            block()
        }.getOrNull()?.let {
            return it
        }

        delay(delayMs)
    }

    return runCatching {
        block()
    }.getOrNull()
}

fun getKisskhTitle(str: String?): String? {
    return str?.replace(Regex("[^a-zA-Z\\d]"), "-")
}


suspend fun <A, B> Iterable<A>.safeAmap(
    concurrency: Int = 7,
    f: suspend (A) -> B?
): List<B> = supervisorScope {
    val semaphore = Semaphore(concurrency)
    map { item ->
        async<B?>(Dispatchers.IO) {
            semaphore.withPermit {
                try {
                    f(item)
                } catch (e: CancellationException) {
                    if (!isActive) throw e
                    null
                } catch (e: Throwable) {
                    Log.e("safeAmap", "Item failed: $item — ${e.message}")
                    null
                }
            }
        }
    }.awaitAll().filterNotNull()
}

suspend fun runLimitedAsync(
    concurrency: Int = 7,
    vararg tasks: suspend () -> Unit
) = supervisorScope {
    val semaphore = Semaphore(concurrency)
    tasks.map { task ->
        async<Unit>(Dispatchers.IO) {
            semaphore.withPermit {
                try {
                    task()
                } catch (e: CancellationException) {
                    if (!isActive) throw e
                } catch (e: Throwable) {
                    Log.e("runLimitedAsync", "Task failed: ${e.message}")
                }
            }
        }
    }.awaitAll()
}

fun getEpisodeSlug(
    season: Int? = null,
    episode: Int? = null,
): Pair<String, String> {
    return if (season == null && episode == null) {
        "" to ""
    } else {
        (if (season!! < 10) "0$season" else "$season") to (if (episode!! < 10) "0$episode" else "$episode")
    }
}

fun getIndexQuality(str: String?): Int {
    if (str.isNullOrBlank()) return Qualities.Unknown.value

    Regex("""(\d{3,4})[pP]""").find(str)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let {
        return it
    }

    val lowerStr = str.lowercase()
    return when {
        lowerStr.contains("8k") -> 4320
        lowerStr.contains("4k") -> 2160
        lowerStr.contains("2k") -> 1440
        else -> Qualities.Unknown.value
    }
}

//Dahmer
fun getIndexQualityTags(str: String?, fullTag: Boolean = false): String {
    return if (fullTag) Regex("(?i)(.*)\\.(?:mkv|mp4|avi)").find(str ?: "")?.groupValues?.get(1)
        ?.trim() ?: str ?: "" else Regex("(?i)\\d{3,4}[pP]\\.?(.*?)\\.(mkv|mp4|avi)").find(
        str ?: ""
    )?.groupValues?.getOrNull(1)
        ?.replace(".", " ")?.trim() ?: str ?: ""
}

suspend fun resolveFinalUrl(startUrl: String): String? {
    var currentUrl = startUrl
    var loopCount = 0
    val maxRedirects = 7

    while (loopCount < maxRedirects) {
        try {
            val res = app.head(currentUrl, allowRedirects = false, timeout = 2500L)
            if (res.code == 200 || res.code in 300..399) {
                val location = res.headers.get("Location")
                if(location.isNullOrEmpty()) break
                currentUrl = location
            } else {
                return null
            }
            loopCount++
        } catch (e: Exception) {
            return null
        }
    }
    return currentUrl
}

fun String.encodeUrl(): String {
    val url = URL(this)
    val uri = URI(url.protocol, url.userInfo, url.host, url.port, url.path, url.query, url.ref)
    return uri.toURL().toString()
}

//Hindmoviez

val HindmoviezSECRET = base64Decode("NWU5NjA4NWM1NmUwZjU0ZWRhNjU3NzkwYWM1OGQxOWIyNzE0NzljNTA0MzY3ZmM5ZTZhNmMzM2YxZjgyNGU2Yg==")

fun hindmoviezbase64Url(input: String): String {
    return base64Encode(input.toByteArray())
        .replace("+", "-")
        .replace("/", "_")
        .replace("=", "")
}

fun hindmoviezhmacSha256(key: String, data: String): String {
    val mac = Mac.getInstance("HmacSHA256")
    val secretKey = SecretKeySpec(key.toByteArray(), "HmacSHA256")
    mac.init(secretKey)
    return mac.doFinal(data.toByteArray())
        .joinToString("") { "%02x".format(it) }
        .substring(0, 16)
}

fun hindmoviezsignHShare(rawId: String, domain: String): String {
    val t = System.currentTimeMillis() / 1000
    val encoded = hindmoviezbase64Url(rawId)
    val s = hindmoviezhmacSha256(HindmoviezSECRET, "$encoded|$t")
    return "$domain/r.php?d=${URLEncoder.encode(encoded, "UTF-8")}&t=$t&s=$s"
}

suspend fun getHindMoviezLinks(
    source: String,
    url: String,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit
) {
    val response = app.get(url)
    val doc = response.document
    val name = doc.select("div.container p:contains(Name:)").text().substringAfter("Name: ")
    val fileSize = doc.select("div.container p:contains(Size:)").text().substringAfter("Size: ")
    val simplifiedTitle = getSimplifiedTitle(name + fileSize)
    val link = doc.select("a.btn-info").attr("href")
    val document = app.get(link, timeout = 30000L).document

    document.select("a.button").safeAmap {
        val source = it.attr("href")

        callback.invoke(
            newExtractorLink(
                "Hindmoviez",
                "Hindmoviez $simplifiedTitle $fileSize",
                source,
                ExtractorLinkType.VIDEO
            ) {
                this.quality = getIndexQuality(name)
            }
        )

    }

}

//For Extractor new domain
suspend fun getLatestBaseUrl(baseUrl: String, source: String): String {
    return try {
        val dynamicUrls = app.get("https://raw.githubusercontent.com/SaurabhKaperwan/Utils/refs/heads/main/urls.json")
            .parsedSafe<Map<String, String>>()
        dynamicUrls?.get(source)?.takeIf { it.isNotBlank() } ?: baseUrl
    } catch (e: Exception) {
        baseUrl
    }
}


//Bold String
fun String.toSansSerifBold(): String {
    val builder = StringBuilder()
    for (char in this) {
        val codePoint = when (char) {
            // Mathematical Sans-Serif Bold ranges
            in 'A'..'Z' -> 0x1D5D4 + (char - 'A')
            in 'a'..'z' -> 0x1D5EE + (char - 'a')
            in '0'..'9' -> 0x1D7EC + (char - '0')
            else -> char.code
        }
        builder.append(Character.toChars(codePoint))
    }
    return builder.toString()
}

suspend fun loadSourceNameExtractor(
    source: String,
    url: String,
    referer: String? = null,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit,
    quality: Int? = null,
    size: String = ""
) = supervisorScope {
    val processLink: (ExtractorLink) -> Unit = { link ->
        launch(Dispatchers.IO) {
            val isDownload = link.source.contains("Download", ignoreCase = true) ||
                             link.url.contains("video-downloads.googleusercontent")
            val simplifiedTitle = getSimplifiedTitle(link.name)
            val combined = if (source.contains("(Combined)")) " (Combined)" else ""
            val fixSize = if (size.isNotEmpty()) " $size" else ""
            val sourceBold = "$source [${link.source}]".toSansSerifBold()
            val newSourceName = if (isDownload) "Download$combined" else "${link.source}$combined"
            val newName = "$sourceBold $simplifiedTitle$fixSize".trim()

            val newLink = newExtractorLink(
                newSourceName,
                newName,
                link.url,
                type = link.type
            ) {
                this.referer = link.referer
                this.quality = quality ?: link.quality
                this.headers = link.headers
                this.extractorData = link.extractorData
            }

            callback(newLink)
        }
    }

    when {
        url.contains("hubcloud.") || url.contains("vcloud.") -> HubCloud().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("gdflix.") || url.contains("gdlink.") -> GDFlix().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("fastdlserver.") -> fastdlserver().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("linksmod.") -> Linksmod().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("hubdrive.") -> Hubdrive().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("gofile.") -> Gofile().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("driveleech.") || url.contains("driveseed.") -> Driveleech().getUrl(url, referer, subtitleCallback, processLink)
        url.contains("howblogs.") -> Howblogs().getUrl(url, referer, subtitleCallback, processLink)
        else -> loadExtractor(url, referer, subtitleCallback, processLink)
    }
}

suspend fun loadCustomExtractor(
    name: String? = null,
    url: String,
    referer: String? = null,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit,
    quality: Int? = null,
    serverName: String = "",
) = supervisorScope {

    val processLink: (ExtractorLink) -> Unit = { link ->
        launch(Dispatchers.IO) {
            val newLink = newExtractorLink(
                name ?: link.source,
                name ?: link.name,
                link.url,
                type = link.type
            ) {
                this.quality = quality ?: link.quality
                this.referer = link.referer
                this.headers = link.headers
                this.extractorData = link.extractorData
            }

            callback(newLink)
        }
    }

    loadExtractor(url, referer, subtitleCallback, processLink)
}

fun fixUrl(url: String, domain: String): String {
    if (url.startsWith("http")) {
        return url
    }
    if (url.isEmpty()) {
        return ""
    }

    val startsWithNoHttp = url.startsWith("//")
    if (startsWithNoHttp) {
        return "https:$url"
    } else {
        if (url.startsWith('/')) {
            return domain + url
        }
        return "$domain/$url"
    }
}

//Anizip
fun getEpAnizipId(json: String, ep: Int): Int? {
    val root = parseJson<Anizip>(json)
    val episode = root.episodes?.get(ep.toString())
    val anidbEid = episode?.anidbEid
    return anidbEid
}

// --- Converts bytes → readable GB/MB ---
fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "-"
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    return when {
        bytes >= gb -> String.format("%.2f GB", bytes / gb)
        bytes >= mb -> String.format("%.2f MB", bytes / mb)
        else -> String.format("%.2f KB", bytes / kb)
    }
}

suspend fun bypassHrefli(url: String): String? {
    fun Document.getFormUrl(): String {
        return this.select("form#landing").attr("action")
    }

    fun Document.getFormData(): Map<String, String> {
        return this.select("form#landing input").associate { it.attr("name") to it.attr("value") }
    }

    val host = getBaseUrl(url)
    var res = app.get(url).document
    var formUrl = res.getFormUrl()
    var formData = res.getFormData()

    res = app.post(formUrl, data = formData).document
    formUrl = res.getFormUrl()
    formData = res.getFormData()

    res = app.post(formUrl, data = formData).document
    val skToken = res.selectFirst("script:containsData(?go=)")?.data()?.substringAfter("?go=")
        ?.substringBefore("\"") ?: return null
    val driveUrl = app.get(
        "$host?go=$skToken", cookies = mapOf(
            skToken to "${formData["_wp_http2"]}"
        )
    ).document.selectFirst("meta[http-equiv=refresh]")?.attr("content")?.substringAfter("url=")
    val path = app.get(driveUrl ?: return null).text.substringAfter("replace(\"")
        .substringBefore("\")")
    if (path == "/404") return null
    return fixUrl(path, getBaseUrl(driveUrl))
}

suspend fun getAniListInfo(animeId: Int): AnimeInfo? {
    val query = """
        query (${'$'}id: Int) {
            Media (id: ${'$'}id, type: ANIME) {
                title {
                    english
                    romaji
                }
                bannerImage
                description(asHtml: false)
            }
        }
    """.trimIndent()

    val requestData = mapOf(
        "query" to query,
        "variables" to mapOf("id" to animeId)
    )

    val response = app.post(
        "https://graphql.anilist.co",
        json = requestData
    ).parsedSafe<AniListResponse>()

    val media = response?.data?.media ?: return null

    val finalBanner = media.bannerImage?.takeUnless { it.isBlank() || it == "null" }
    val finalTitle = media.title?.english?.takeUnless { it.isBlank() || it == "null" }
    val finaromajiTitle = media.title?.romaji?.takeUnless { it.isBlank() || it == "null" }
    val finalDescription = media.description?.takeUnless { it.isBlank() || it == "null" }

    return AnimeInfo(
        title = finalTitle,
        romajiTitle = finaromajiTitle,
        banner = finalBanner,
        description = finalDescription
    )
}

suspend fun convertTmdbToAnimeId(
    title: String?,
    date: String?,
    airedDate: String?,
    type: TvType
): AniIds {
    val sDate = date?.split("-")
    val sAiredDate = airedDate?.split("-")

    val year = sDate?.firstOrNull()?.toIntOrNull()
    val airedYear = sAiredDate?.firstOrNull()?.toIntOrNull()
    val season = getSeason(sDate?.get(1)?.toIntOrNull())
    val airedSeason = getSeason(sAiredDate?.get(1)?.toIntOrNull())

    return if (type == TvType.AnimeMovie) {
        tmdbToAnimeId(title, airedYear, "", type)
    } else {
        tmdbToAnimeId(title, year, season, type)
    }
}

suspend fun convertImdbToAnimeId(
    title: String?,
    year: Int?,
    airedDate: String?,
    type: TvType
): AniIds {
    val sAiredDate = airedDate?.split("-")
    val airedYear = sAiredDate?.firstOrNull()?.toIntOrNull()
    val airedSeason = getSeason(sAiredDate?.get(1)?.toIntOrNull())

    return if (type == TvType.AnimeMovie) {
        tmdbToAnimeId(title, year, "", type)
    } else {
        tmdbToAnimeId(title, airedYear, airedSeason, type)
    }
}

suspend fun tmdbToAnimeId(title: String?, year: Int?, season: String?, type: TvType): AniIds {
    val anilistAPI = "https://graphql.anilist.co"
    val query = """
        query (
          ${'$'}page: Int = 1
          ${'$'}search: String
          ${'$'}sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
          ${'$'}type: MediaType
          ${'$'}season: MediaSeason
          ${'$'}seasonYear: Int
          ${'$'}format: [MediaFormat]
        ) {
          Page(page: ${'$'}page, perPage: 20) {
            media(
              search: ${'$'}search
              sort: ${'$'}sort
              type: ${'$'}type
              season: ${'$'}season
              seasonYear: ${'$'}seasonYear
              format_in: ${'$'}format
            ) {
              id
              idMal
            }
          }
        }
    """.trimIndent()

    val variables = mapOf(
        "search" to title,
        "sort" to "SEARCH_MATCH",
        "type" to "ANIME",
        "season" to season?.uppercase(),
        "seasonYear" to year,
        "format" to listOf(if (type == TvType.AnimeMovie) "MOVIE" else "TV", "ONA")
    ).filterValues { it != null && it.toString().isNotEmpty() }

    val res = app.post(
        url = anilistAPI,
        json = mapOf(
            "query" to query,
            "variables" to variables
        )
    ).parsedSafe<AniSearch>()?.data?.Page?.media?.firstOrNull()

    return AniIds(res?.id, res?.idMal)
}

fun getSeason(month: Int?): String? {
    val seasons = arrayOf(
        "Winter", "Winter", "Spring", "Spring", "Spring", "Summer",
        "Summer", "Summer", "Fall", "Fall", "Fall", "Winter"
    )
    if (month == null) return null
    return seasons[month - 1]
}

suspend fun fetchTmdbLogoUrl(
    tmdbAPI: String,
    apiKey: String,
    type: TvType,
    tmdbId: Int?,
    appLangCode: String?
): String? {

    if (tmdbId == null) return null

    val url = if (type == TvType.Movie)
        "$tmdbAPI/movie/$tmdbId/images?api_key=$apiKey"
    else
        "$tmdbAPI/tv/$tmdbId/images?api_key=$apiKey"

    val json = runCatching { JSONObject(app.get(url).text) }.getOrNull() ?: return null
    val logos = json.optJSONArray("logos") ?: return null
    if (logos.length() == 0) return null

    val lang = appLangCode?.trim()?.lowercase()?.substringBefore("-")

    fun path(o: JSONObject) = o.optString("file_path")
    fun isSvg(o: JSONObject) = path(o).endsWith(".svg", true)
    fun urlOf(o: JSONObject) = "https://image.tmdb.org/t/p/w500${path(o)}"

    // Language match
    var svgFallback: JSONObject? = null

    for (i in 0 until logos.length()) {
        val logo = logos.optJSONObject(i) ?: continue
        val p = path(logo)
        if (p.isBlank()) continue

        val l = logo.optString("iso_639_1").trim().lowercase()
        if (l == lang) {
            if (!isSvg(logo)) return urlOf(logo)
            if (svgFallback == null) svgFallback = logo
        }
    }
    svgFallback?.let { return urlOf(it) }

    // Highest voted fallback
    var best: JSONObject? = null
    var bestSvg: JSONObject? = null

    fun voted(o: JSONObject) = o.optDouble("vote_average", 0.0) > 0 && o.optInt("vote_count", 0) > 0

    fun better(a: JSONObject?, b: JSONObject): Boolean {
        if (a == null) return true
        val aAvg = a.optDouble("vote_average", 0.0)
        val aCnt = a.optInt("vote_count", 0)
        val bAvg = b.optDouble("vote_average", 0.0)
        val bCnt = b.optInt("vote_count", 0)
        return bAvg > aAvg || (bAvg == aAvg && bCnt > aCnt)
    }

    for (i in 0 until logos.length()) {
        val logo = logos.optJSONObject(i) ?: continue
        if (!voted(logo)) continue

        if (isSvg(logo)) {
            if (better(bestSvg, logo)) bestSvg = logo
        } else {
            if (better(best, logo)) best = logo
        }
    }

    best?.let { return urlOf(it) }
    bestSvg?.let { return urlOf(it) }

    // No language match & no voted logos
    return null
}

suspend fun generateMagnetLink(url: String, hash: String?): String {
    val response = app.get(url)
    val trackerList = response.text.trim().split("\n")

    // Build the magnet link
    return buildString {
        append("magnet:?xt=urn:btih:$hash")
        trackerList.forEach { tracker ->
            if (tracker.isNotBlank()) {
                append("&tr=").append(tracker.trim())
            }
        }
    }
}

suspend fun getRedirectLinks(url: String): String {
    fun encode(value: String): String {
        return base64Encode(value.toByteArray())
    }

    fun decode(value: String): String {
        return base64Decode(value)
    }

    fun rot13(value: String): String {
        return value.map {
            when (it) {
                in 'A'..'Z' -> 'A' + (it - 'A' + 13) % 26
                in 'a'..'z' -> 'a' + (it - 'a' + 13) % 26
                else -> it
            }
        }.joinToString("")
    }

    return try {
        val doc = app.get(url).text

        val regex = """s\('o','([A-Za-z0-9+/=]+)'|ck\('_wp_http_\d+','([^']+)'""".toRegex()

        val combinedString = regex.findAll(doc)
            .mapNotNull { it.groups[1]?.value ?: it.groups[2]?.value }
            .joinToString("")

        if (combinedString.isEmpty()) return ""

        val decodedString = decode(rot13(decode(decode(combinedString))))
        val jsonObject = JSONObject(decodedString)

        val encodedUrl = decode(jsonObject.optString("o", "")).trim()
        val data = encode(jsonObject.optString("data", "")).trim()
        val wphttp1 = jsonObject.optString("blog_url", "").trim()

        val directLink = if (wphttp1.isNotEmpty() && data.isNotEmpty()) {
            runCatching {
                app.get("$wphttp1?re=$data").document.select("body").text().trim()
            }.getOrDefault("")
        } else {
            ""
        }

        encodedUrl.ifEmpty { directLink }
    } catch (e: Exception) {
        ""
    }
}

fun decryptVidzeeUrl(encryptedUrl: String, secret: String): String? {
    return try {
        val decodedString = base64Decode(encryptedUrl)
        val parts = decodedString.split(":", limit = 2)
        if (parts.size < 2) return null

        val iv         = base64DecodeArray(parts[0])
        val ciphertext = base64DecodeArray(parts[1])

        val key = secret.padEnd(32, '\u0000').toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }
}


//Vidrock

fun decryptVidrockUrl(encryptedPayload: String): String? {
    return try {
        val aesKeyHex = "7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f"
        val keyBytes = aesKeyHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

        var standardBase64 = encryptedPayload.replace("-", "+").replace("_", "/")

        while (standardBase64.length % 4 != 0) {
            standardBase64 += "="
        }

        val encryptedData = base64DecodeArray(standardBase64)

        val nonce = encryptedData.copyOfRange(0, 12)
        val cipherTextWithTag = encryptedData.copyOfRange(12, encryptedData.size)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(keyBytes, "AES")
        val gcmSpec = GCMParameterSpec(128, nonce)

        cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec)
        val decryptedBytes = cipher.doFinal(cipherTextWithTag)

        String(decryptedBytes, Charsets.UTF_8)
    } catch (e: Exception) {
        Log.e("Vidrock", "Decryption failed")
        null
    }
}

//Xpass
fun extractXpassBackups(html: String): List<Pair<String, String>> {
    val raw = Regex("""var backups=(\[.*?]);""", RegexOption.DOT_MATCHES_ALL)
        .find(html)?.groupValues?.get(1) ?: return emptyList()
    val array = JSONArray(raw)
    return (0 until array.length()).mapNotNull { i ->
        val obj  = array.getJSONObject(i)
        val name = obj.optString("name").takeIf { it.isNotBlank() } ?: return@mapNotNull null
        val url  = obj.optString("url").takeIf  { it.isNotBlank() } ?: return@mapNotNull null
        Pair(name, url)
    }
}


//Peachify
fun peachifyDecrypt(encrypt: String): String? {
    return try {
        val parts = encrypt.split(".")
        if (parts.size < 3) return null

        val iv         = b64UrlDecode(parts[0])
        val cipherData = b64UrlDecode(parts[1]) + b64UrlDecode(parts[2])

        val keyBytes = "a8f2a1b5e9c470814f6b2c3a5d8e7f9c1a2b3c4d5e3f7a8b8cad1e2d0a4d5c5d"
            .chunked(2)
            .map { it.toInt(16).toByte() }
            .toByteArray()

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(keyBytes, "AES"),
            GCMParameterSpec(128, iv)
        )
        String(cipher.doFinal(cipherData), Charsets.UTF_8)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

fun b64UrlDecode(s: String): ByteArray {
    return s.replace('-', '+').replace('_', '/')
        .let { it + "=".repeat((4 - it.length % 4) % 4) }
        .let { base64DecodeArray(it) }
}

//Zinkmovies

fun extractSeasonLinks(content: org.jsoup.nodes.Element, season: Int): List<String> {
    val links = mutableListOf<String>()
    var inTargetSeason = false
    content.children().forEach { child ->
        when {
            child.hasClass("lgtagmessage") -> {
                inTargetSeason = Regex("""Season\s+0*$season\b""", RegexOption.IGNORE_CASE)
                .containsMatchIn(child.text())
            }
            child.hasClass("movie-button-container") && inTargetSeason -> {
                child.selectFirst("a.movie-simple-button")
                    ?.attr("href")
                    ?.takeIf(String::isNotBlank)
                    ?.let { links.add(it) }
            }
        }
    }
    return links
}

suspend fun generateZinkLinks(url: String): List<ZinkLink> {
    return runCatching {

        val firstDoc = app.get(url).document
        val title = firstDoc.select("h1.file-title").text()
        val firstHtml = firstDoc.html()

        val randomId = Regex("""generateDownloadLink\(['"]([^'"]+)""")
            .find(firstHtml)
            ?.groupValues
            ?.getOrNull(1)
            ?: return emptyList()

        val ajaxEndpoint = Regex("""https://[^"'\\s]+ajax_generate_token\.php""")
            .find(firstHtml)
            ?.value
            ?: return emptyList()

        val downloadBase = Regex("""https://[^"'\\s]+/dl/""")
            .find(firstHtml)
            ?.value
            ?: return emptyList()

        val token = retry  { app.post(
            url = "$ajaxEndpoint?random_id=$randomId",
            data = mapOf(
                "random_id" to randomId
            ),
            headers = mapOf(
                "X-Requested-With" to "XMLHttpRequest"
            )
        ).parsedSafe<ZinkTokenResponse>()
            ?.token

        } ?: return emptyList()

        val generatedUrl = downloadBase + token

        val generatedDoc = app.get(generatedUrl).document

        val results = generatedDoc
            .select("#mirror-buttons a[href]")
            .mapNotNull { element ->

                val href = element.attr("href").trim()

                if (href.isBlank()) return@mapNotNull null

                ZinkLink(
                    name = element.text()
                        .replace("Generate", "", true)
                        .trim(),
                    url = href,
                    title = title,
                )
            }
            .toMutableList()

        generatedDoc.selectFirst("#worker-btn")?.let { btn: Element ->

            val workerId = Regex("""handleServerRequest\(['"]worker['"]\s*,\s*['"]([^'"]+)""")
                .find(btn.attr("onclick"))
                ?.groupValues
                ?.getOrNull(1)

            val serverHandler = Regex("""SERVER_HANDLER_URL\s*=\s*["']([^"']+)""")
                .find(generatedDoc.html())
                ?.groupValues
                ?.getOrNull(1)

            if (
                !workerId.isNullOrBlank() &&
                !serverHandler.isNullOrBlank()
            ) {

                runCatching {

                    val workerJson = JSONObject(
                        app.post(
                            url = serverHandler,
                            requestBody = """
                                {
                                    "server":"worker",
                                    "random_id":"$workerId"
                                }
                            """.trimIndent().toRequestBody(),
                            headers = mapOf(
                                "X-Requested-With" to "XMLHttpRequest",
                                "Content-Type" to "application/json",
                                "Origin" to generatedUrl.substringBefore("/dl/"),
                                "Referer" to generatedUrl
                            )
                        ).text
                    )

                    workerJson.optString("url")
                        .ifBlank {
                            workerJson.optString("download")
                        }
                        .takeIf { it.isNotBlank() }
                        ?.let {
                            results += ZinkLink(
                                name = "WORKER",
                                url = it,
                                title = title,
                            )
                        }

                }
            }
        }

        results.distinctBy { it.url }

    }.getOrElse {
        emptyList()
    }
}


suspend fun getZinkLinks(
    source: String,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit
) {
    generateZinkLinks(source).safeAmap { link ->

        val simplifiedTitle = getSimplifiedTitle(link.title)

        if (link.name.contains("worker", true)) {
            callback(
                newExtractorLink(
                    source = "Zinkmovies Worker",
                    name = "Zinkmovies Worker $simplifiedTitle",
                    url = link.url
                ) {
                    this.quality = getIndexQuality(link.title)
                }
            )
        } else {
            loadSourceNameExtractor(
                "Zinkmovies",
                link.url,
                "",
                subtitleCallback,
                callback
            )
        }
    }
}

//Showbox

val SHOWBOX_HEADERS = mapOf(
    "Accept"          to "application/json, text/html, */*",
    "Accept-Language" to "en",
    "User-Agent"      to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
)

suspend fun searchSuperstream(imdbId: String): Int? {
    repeat(7) { attempt ->
        val result = runCatching {
            val searchHtml = app.get(
                "$showboxAPI/search?keyword=$imdbId",
                headers = SHOWBOX_HEADERS
            ).text
            val detailUrl  = parseSearchHref(searchHtml) ?: return@runCatching null
            val detailHtml = app.get(detailUrl, headers = SHOWBOX_HEADERS).text
            parseHeadingId(detailHtml)
        }.getOrNull()

        if (result != null) return result
        Log.d("Showbox", "searchSuperstream attempt ${attempt + 1} failed")
        delay(100)
    }
    return null
}

fun parseHeadingId(html: String): Int? {
    return Regex("""class="heading-name[^"]*"[^>]*>[\s\S]*?<a[^>]+href="([^"]+)\"""")
        .find(html)
        ?.groupValues?.get(1)
        ?.split("/")
        ?.lastOrNull()
        ?.toIntOrNull()
}

fun parseSearchHref(html: String): String? {
    return (Regex("""class="film-name[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)\"""").find(html)
        ?: Regex("""<a[^>]+href="([^"]+)"[^>]*class="[^"]*film-name[^"]*\"""").find(html))
        ?.groupValues?.get(1)
        ?.let { "$showboxAPI$it" }
}

suspend fun getShareKey(mediaId: Int, type: Int): String? {

    return runCatching {
        app.get(
            "$showboxAPI/index/share_link?id=$mediaId&type=$type",
            headers = SHOWBOX_HEADERS
        ).parsedSafe<ShareLinkResponse>()
            ?.data?.link
            ?.split("/")
            ?.lastOrNull()
    }.getOrNull()
}

suspend fun getFileList(shareKey: String, parentId: Long? = null, page: Int = 1): FileListData? {

    return runCatching {
        val url = buildString {
            append("$febboxAPI/file/file_share_list?share_key=$shareKey")
            if (parentId != null) append("&parent_id=$parentId&page=$page")
        }
        app.get(url, headers = SHOWBOX_HEADERS).parsedSafe<FileListResponse>()?.data
    }.getOrNull()
}

suspend fun getVideoQualities(fid: Long, shareKey: String, febboxToken: String): List<VideoQuality> {
    return runCatching {
        val html = app.get(
            "$febboxAPI/console/video_quality_list?fid=$fid&share_key=$shareKey",
            headers = SHOWBOX_HEADERS + mapOf("Cookie" to normalizeToken(febboxToken))
        ).parsedSafe<VideoQualityResponse>()?.html ?: return emptyList()
        parseQualityDivs(html)
    }.getOrElse { emptyList() }
}

fun normalizeToken(token: String): String = when {
    token.startsWith("eyJ") -> "ui=$token"
    token.startsWith("ui=") -> token
    else                    -> "ui=$token"
}

fun parseQualityDivs(html: String): List<VideoQuality> {
    return Regex("""<div[^>]*class="[^"]*file_quality[^"]*"[^>]*>""")
        .findAll(html)
        .mapNotNull { match ->
            val tag     = match.value
            val url     = Regex("""data-url="([^"]+)\"""").find(tag)?.groupValues?.get(1) ?: return@mapNotNull null
            val quality = Regex("""data-quality="([^"]+)\"""").find(tag)?.groupValues?.get(1) ?: return@mapNotNull null
            VideoQuality(url = url.replace("\\/", "/"), quality = quality)
        }.toList()
}

//Anichi

fun decodeToBeParsed(encoded: String): String? {
    return try {
        val raw = base64DecodeArray(encoded)

        if (raw.size < 29) return null

        val iv = raw.copyOfRange(1, 13)

        val ctr = ByteArray(16)
        System.arraycopy(iv, 0, ctr, 0, iv.size)
        ctr[15] = 0x02

        val ciphertext = raw.copyOfRange(13, raw.size - 16)

        val key = MessageDigest
            .getInstance("SHA-256")
            .digest("Xot36i3lK3:v1".toByteArray())

        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(key, "AES"),
            IvParameterSpec(ctr)
        )

        cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

//Castle

val castleHeaders = mapOf(
    "User-Agent" to "okhttp/4.9.3",
    "Accept" to "application/json",
    "Accept-Language" to "en-US,en;q=0.9",
    "Connection" to "Keep-Alive",
    "Referer" to "$castleAPI/"
)

fun decryptCastle(cipherText: String, base64Key: String): String {
    val pepperWords = "T!BgJB".toByteArray(Charsets.UTF_8)

    val keyWords = base64DecodeArray(base64Key)
    val combined = keyWords + pepperWords

    val keyMaterial = ByteArray(16)
    System.arraycopy(combined, 0, keyMaterial, 0, min(combined.size, 16))

    val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    val secretKeySpec = SecretKeySpec(keyMaterial, "AES")
    val ivParameterSpec = IvParameterSpec(keyMaterial)

    cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec)

    val cipherBytes = base64DecodeArray(cipherText)

    return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
}

suspend fun getCastleSecurityKey(url: String): String {
    val response = app.get(url, headers = castleHeaders).text
    val json = JSONObject(response)
    return json.optString("data")
}

suspend fun makeCastleApiRequest(
    url: String,
    securityKey: String,
    method: String = "GET",
    jsonBody: Any? = null
): JSONObject {
    val response = if (method == "POST" && jsonBody != null) {
        app.post(url, headers = castleHeaders, json = jsonBody).text
    } else {
        app.get(url, headers = castleHeaders).text
    }.trim()

    val cipherText = try {
        val tempJson = JSONObject(response)
        if (tempJson.has("data") && tempJson.get("data") is String) {
            tempJson.getString("data")
        } else {
            response
        }
    } catch (e: Exception) {
        response
    }

    val decryptedStr = decryptCastle(cipherText, securityKey)

    val finalJson = JSONObject(decryptedStr)
    return finalJson.optJSONObject("data") ?: finalJson
}

//CtgMovies

fun unescapeNextChunk(raw: String): String {
    val sb = StringBuilder(raw.length)
    var i = 0
    while (i < raw.length) {
        val c = raw[i]
        if (c == '\\' && i + 1 < raw.length) {
            when (raw[i + 1]) {
                '"' -> { sb.append('"'); i += 2 }
                '\\' -> { sb.append('\\'); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'u' -> {
                    if (i + 5 < raw.length) {
                        val hex = raw.substring(i + 2, i + 6)
                        sb.append(hex.toInt(16).toChar())
                        i += 6
                    } else { sb.append(c); i++ }
                }
                else -> { sb.append(raw[i + 1]); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}

// Concatenate every self.__next_f.push chunk into one big decoded blob
fun buildRscBlob(html: String): String {
    val NEXT_F_PREFIX = "self.__next_f.push([1,\""
    val NEXT_F_SUFFIX = "\"])"
    val blob = StringBuilder()
    var searchFrom = 0
    while (true) {
        val start = html.indexOf(NEXT_F_PREFIX, searchFrom)
        if (start == -1) break
        val contentStart = start + NEXT_F_PREFIX.length
        val end = html.indexOf(NEXT_F_SUFFIX, contentStart)
        if (end == -1) break
        val raw = html.substring(contentStart, end)
        blob.append(unescapeNextChunk(raw))
        searchFrom = end + NEXT_F_SUFFIX.length
    }
    return blob.toString()
}

// Extract EVERY balanced "links":[...] JSON array found in the blob.
fun extractAllLinksArraysJson(blob: String): List<String> {
    val key = "\"links\":["
    val results = mutableListOf<String>()
    var searchFrom = 0
    while (true) {
        val keyIdx = blob.indexOf(key, searchFrom)
        if (keyIdx == -1) break
        val arrStart = keyIdx + key.length - 1 // position of '['
        var depth = 0
        var i = arrStart
        var arrEnd = -1
        while (i < blob.length) {
            when (blob[i]) {
                '[' -> depth++
                ']' -> {
                    depth--
                    if (depth == 0) { arrEnd = i; break }
                }
            }
            i++
        }
        if (arrEnd == -1) break
        results.add(blob.substring(arrStart, arrEnd + 1))
        searchFrom = arrEnd + 1
    }
    return results
}

fun parseCtgLinks(html: String): List<CTGLink> {
    val blob = buildRscBlob(html)
    val arrJsonList = extractAllLinksArraysJson(blob)
    if (arrJsonList.isEmpty()) return emptyList()

    val result = mutableListOf<CTGLink>()
    for (arrJson in arrJsonList) {
        val arr = runCatching { JSONArray(arrJson) }.getOrNull() ?: continue
        for (idx in 0 until arr.length()) {
            val obj = arr.optJSONObject(idx) ?: continue
            val url = obj.optString("url").takeIf { it.isNotBlank() } ?: continue

            val audioTracks = mutableListOf<Pair<String, String>>()
            obj.optJSONArray("audio_tracks")?.let { tracksArr ->
                for (j in 0 until tracksArr.length()) {
                    val t = tracksArr.optJSONObject(j) ?: continue
                    val aUrl = t.optString("url")
                    val label = t.optString("label", t.optString("language", ""))
                    if (aUrl.isNotBlank()) audioTracks.add(aUrl to label)
                }
            }

            result.add(
                CTGLink(
                    quality = obj.optString("quality"),
                    url = url,
                    hlsUrl = obj.optString("hls_url").takeIf { it.isNotBlank() && it != "null" },
                    type = obj.optString("type"),
                    source = obj.optString("source"),
                    language = obj.optString("language"),
                    sizeBytes = obj.optLong("size_bytes", -1L).takeIf { it >= 0 },
                    seasonNumber = obj.optInt("season_number", -1).takeIf { it >= 0 },
                    episodeNumber = obj.optInt("episode_number", -1).takeIf { it >= 0 },
                    audioTracks = audioTracks
                )
            )
        }
    }

    // Dedup in case the same link array got captured twice via overlapping matches
    return result.distinctBy { it.url }
}

//MovieBlast

fun generateSignedUrl(url: String): String? {
    return try {
        val uri = URI(url)

        val path = uri.rawPath

        val timestamp = (System.currentTimeMillis() / 1000).toString()

        val mac = Mac.getInstance("HmacSHA256")
        val secretKeySpec = SecretKeySpec(MOVIEBLAST_KEY.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(secretKeySpec)

        val hmacData = mac.doFinal((path + timestamp).toByteArray(Charsets.UTF_8))

        val signature = base64Encode(hmacData)
        val encodedSignature = URLEncoder.encode(signature, "UTF-8")

        "$url?verify=$timestamp-$encodedSignature"
    } catch (e: Exception) {
        null
    }
}

//Fibwatch

val fibwatchHeaders = mapOf(
    "User-Agent" to USER_AGENT,
    "Referer" to "$fibwatchBaseUrl/"
)

val fibwatchPlaybackHeaders = mapOf(
    "User-Agent" to USER_AGENT,
    "Referer" to "https://urlshortlink.top/",
    "Origin" to "https://urlshortlink.top"
)

fun extractFibwatchQuality(raw: String?): String {
    val lower = raw?.lowercase() ?: ""
    return when {
        lower.contains("2160") || lower.contains("4k") -> "4K"
        lower.contains("1080") -> "1080p"
        lower.contains("720") -> "720p"
        lower.contains("480") -> "480p"
        lower.contains("360") -> "360p"
        else -> "Unknown"
    }
}

suspend fun resolveFibwatchStream(initialUrl: String, fallbackQuality: String): Pair<String, String>? {
    var currentUrl = initialUrl
    var html = runCatching { app.get(currentUrl, headers = fibwatchHeaders).text }.getOrNull() ?: return null

    val doc1 = Jsoup.parse(html)

    val genericMediaRegex = Regex("""https?://[a-zA-Z0-9-.]+(?:/[^\s"'`<>]*)?\.(?:mp4|mkv|m3u8)""", RegexOption.IGNORE_CASE)
    val fibwatchCdnRegex = Regex("""https?://[a-zA-Z0-9-]+\.b-cdn\.net/[^\s"'`<>]+\.(?:mkv|mp4|m3u8)""", RegexOption.IGNORE_CASE)

    var nextPath = doc1.selectFirst("a.hidden-button.buttonDownloadnew")?.attr("href")
    if (nextPath.isNullOrBlank()) {
        nextPath = doc1.select("a").firstOrNull { it.attr("href").contains("watch2=1") }?.attr("href")
    }

    if (!nextPath.isNullOrBlank()) {
        var targetUrl = nextPath
        if (nextPath.contains("url=http")) {
            val encoded = nextPath.substringAfter("url=").substringBefore("&").trim()
            targetUrl = runCatching { URLDecoder.decode(encoded, "UTF-8") }.getOrDefault(encoded)
            if (genericMediaRegex.containsMatchIn(targetUrl) || fibwatchCdnRegex.containsMatchIn(targetUrl)) {
                return targetUrl to fallbackQuality
            }
        }

        currentUrl = URI(currentUrl).resolve(targetUrl).toString()
        html = runCatching { app.get(currentUrl, headers = fibwatchHeaders).text }.getOrNull() ?: return null
    }

    val doc2 = Jsoup.parse(html)
    var streamUrl = fibwatchCdnRegex.find(html)?.value

    if (streamUrl == null) {
        val iframeSrc = doc2.select("iframe").map { it.attr("src") }
            .firstOrNull { it.isNotBlank() && !it.contains("youtube") && !it.contains("google") }

        if (iframeSrc != null) {
            val absoluteIframeUrl = URI(currentUrl).resolve(iframeSrc).toString()
            val iframeHtml = runCatching { app.get(absoluteIframeUrl, headers = fibwatchPlaybackHeaders).text }.getOrNull()
            if (iframeHtml != null) {
                streamUrl = fibwatchCdnRegex.find(iframeHtml)?.value ?: genericMediaRegex.find(iframeHtml)?.value
            }
        }
    }

    if (streamUrl == null) {
        streamUrl = genericMediaRegex.find(html)?.value
    }

    if (streamUrl != null) {
        if (streamUrl.contains("url=http", ignoreCase = true)) {
            val encoded = streamUrl.substringAfter("url=").substringBefore("&").trim()
            streamUrl = runCatching { URLDecoder.decode(encoded, "UTF-8") }.getOrDefault(encoded)
        }

        val realQuality = extractFibwatchQuality(streamUrl)
        val finalQuality = if (realQuality != "Unknown") realQuality else fallbackQuality
        return streamUrl to finalQuality
    }

    return null
}
